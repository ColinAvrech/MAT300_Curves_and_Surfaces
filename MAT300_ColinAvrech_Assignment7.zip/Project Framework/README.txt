MAT300_Summer14_Assignment7 Readme
Author: Colin Avrech
Date: 07/14/2014

Please open the method menu and navigate to Assignment3->Polynomial Interpolation.

Program calculates a polynomial that intersects all input points.

Controls for Assignment7
============================
Right Mouse Button - Move Nearest Point

If you need to contact me you can reach me at colin.avrech@gmail.com or 
by phone at (425)221-5903

Code Locations
File: mat300.cs
Line 785: Drawing code
Line 1488: Mathematical algorithms
